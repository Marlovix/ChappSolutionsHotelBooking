$(document).ready(function() {

    $('#bookings-table').DataTable({
        ordering: false,
        language: {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
        }
    });
});